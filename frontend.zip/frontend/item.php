<?php
    include '../APIs/ItemApis.php';
    include '../APIs/CartApis.php';
    session_start();
    $connection = mysqli_connect("localhost", "root", "root", "BuyingAndSelling");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <style>
            .backGround {
                background-image: url('https://whatsyouredge.com.au/wp-content/uploads/2017/11/open-book.jpg');
            }
            @media(orientation:portrait) {
                .full {
                    background-size: 100% auto;
                    background-position: top right;
                }
            }
        </style>
    </head>
    <body>
        <div class="full backGround">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4 text-left">
                        <button onClick="document.location.href='cart.php'" class="btn btn-primary" type="submit">My cart: <?php echo $total_items;?> items</button>
                    </div>
                    <div class="col-sm-4 text-center">
                        <h2>Welcome, Jackob!</h2>
                    </div>
                    <div class="col-sm-4 text-right">
                        <button href="#" class="btn btn-primary" type="submit">Sell</button>
                        <button href="Accounts.html" class="btn btn-primary" type="submit">My Account</button>
                        <button href="LoginScreen.html" class="btn btn-primary" type="submit">Logout</button>
                    </div>
                </div>
            </div>
            <div class="container-fluid text-center">
                <div class="row">
                    <div class="col-sm-4"></div>
                    <img src="logo.jpeg" alt="website logo" class="text-right img-circle col-sm-2">
                    <h1 class="col-sm-6 text-left">Schoolify</h1>
                </div>
            </div>
            <?php
            $result = getItem($connection,1);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    <div class="container text-center">
                        <div class="row">
                            <div class="col-sm-4">
                                <h4><?php echo $row["ItemName"];?></h4>
                                <img src="<?php echo $row["ItemImage"];?>" alt="<?php echo $row["ItemImage"];?>" class="img-rounded">
                            </div>
                            <div class="col-sm-8">                        
                                <h3>Category: <?php echo $row["CategoryID"];?></h3>
                                <h5 class="text-left">Price: $<?php echo number_format($row["ItemPrice"], 2, '.', '')?></h5>
                                <p class="jumbotron">Sellers Description: <?php echo $row["ItemDescription"]?>
                                </p>
                            <div class="row">
                                <div class="col-sm-4">
                                    <form method="post" action="../APIs/CartApis.php" >
                                        <input type="hidden" name="hiddenId" value="<?php $row["ItemID"];?>"/>
                                        <button type="button" name="add_to_cart" class="btn btn-success text-left" value="Add to my cart">Add to my cart</button>
                                    </form>
                                </div>
                                <div class="col-sm-4">
                                    <button type="button" class="btn btn-info text-center">Contact Seller</button>
                                </div>
                                <div class="col-sm-4">
                                    <button type="button" class="btn btn-danger text-right">Homepage</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container text-left">
                    <div class="row">
                        <h2>User product reviews</h2>
                    </div>
                </div>
                
                <div class="container text-center">
                    <div class="row">
                    <?php
                        $result = getReviews($connection, 1);
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result)) {
                                ?>
                                <div class="jumbotron">
                            <h5 class="text-left"><?php echo $row["Reviewer_name"];?></h5>
                            <p class="jubotron">
                                <?php echo $row["Review"];?>
                            </p>
                        </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>
                            <?php
                        }
                    }
                ?>
        </div>
    </body>
</html>