<!DOCTYPE html>
<html lang="en">
<body>
<form action="post-method.php" method="post">

<input type="text" name="firstname" placeholder="First Name" />

<input type="text" name="lastname" placeholder="Last Name" />

<input type="submit" name="submit" />
</form> 
</body>
</html>

