
<?php
    include '../APIs/CartApis.php';
    session_start();
    $connection = mysqli_connect("localhost", "root", "root", "BuyingAndSelling");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
            .backGround {
                background-image: url('https://whatsyouredge.com.au/wp-content/uploads/2017/11/open-book.jpg');
            }
            @media(orientation:portrait) {
                .full {
                    background-size: 100% auto;
                    background-position: top right;
                }
            }
        </style>
    </head>
    <body class="full backGround">
        <div">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4 text-left">
                        <button href="myCart.html" class="btn btn-primary invisible" type="submit">My cart: <?php echo $total_items;?> items</button>
                    </div>
                    <div class="col-sm-4 text-center">
                        <h2>Welcome, Jackob!</h2>
                    </div>
                    <div class="col-sm-4 text-right">
                        <button href="Accounts.html" class="btn btn-primary" type="submit" href>My Account</button>
                        <button href="LoginScreen.html" class="btn btn-primary" type="submit">Logout</button>
                    </div>
                </div>
            </div>
            <div class="container-fluid text-center">
                <div class="row">
                    <div class="col-sm-4"></div>
                    <img src="logo.jpeg" alt="website logo" class="text-right img-circle col-sm-2">
                    <h1 class="col-sm-6 text-left">Schoolify</h1>
                </div>
            </div>
            <div class="container-fluid text-left">
                <h3>My Cart:</h3>
            </div>
            <div class="container-fluid">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Item name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Price</th>
                            <th scope="col">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <?php
                            $result = getCartItems($connection, 1);
                            $output = array();
                            if ($row = mysqli_fetch_array($result)) {
                                ?>
                                <tr>
                                    <td><?php echo $row['ItemName']; ?></td>
                                    <td><?php echo $row['CategoryID']; ?></td>
                                    <td><?php echo $row['ItemPrice']; ?></td>
                                    <td><?php echo 'button' ?></td>
                                </tr>
                                <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-11 text-right">
                        <h4>Total number of items:</h4>
                    </div>
                    <div class="col-sm-1 text-right">
                        <?php
                            $total_items = $total_items + $values["item_quantity"];
                        ?>
                        <h4><?php echo $total_items;?></h4>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-11 text-right">
                        <h4>Shipping price:</h4>
                    </div>
                    <div class="col-sm-1 text-right">
                    <?php
                        $shipping_total = $shipping_total + ($values["item_quantity"] * $values["item_shipping_price"]);
                    ?>
                        <h4>$<?php echo number_format($shipping_total, 2);?></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-11 text-right">
                        <h4>Total price:</h4>
                    </div>
                    <div class="col-sm-1 text-right">
                    <?php
                            $total = $total + ($values["item_quantity"] * $values["item_price"]) + $shipping_total;
                        ?>
                        <h4>$<?php echo number_format($total, 2);?></h4>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 text-right">
                        <div class="col-sm-10 text-right">
                            <button class="btn btn-secondary">Continue Shopping</button>
                        </div>
                        <div class="col-sm-2 text-right">
                            <button class="btn btn-success">Proceed to Checkout</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>