<?php
    if (isset($_POST['submit'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        echo "$firstname and $lastname";
        exit;
    }
?>