<html>
<body>
<?php
    $con = mysqli_connect("localhost", "root", "root", "");
    if (mysqli_connect_errno($con)) {
        echo "Falied to connect to MySQL: " . mysqli_connect_error() . "<br>";
    }
    echo "Connection Successful.<br>";
    $databaseName = "BuyingAndSelling";
    $sql = "CREATE DATABASE IF NOT EXISTS $databaseName";
    if (mysqli_query($con, $sql)) {
        $sql = "USE $databaseName";
        if (mysqli_query($con, $sql)) {
            echo "$databaseName selected.<br>";
            $table = "ITEM";
            $table2 = "ITEM_REVIEWS";
            $table3 = "CART";
            $sql = "CREATE TABLE IF NOT EXISTS $table (
                ItemID int NOT NULL PRIMARY KEY,
                SellerUserID int NOT NULL,
                ItemName varchar(255),
                ItemDescription LONGTEXT,
                ItemPrice FLOAT,
                NumberOfItems int,
                CategoryID varchar(20) NOT NULL,
                ShipPrice FLOAT,
                ArrivalDate varchar(20),
                ItemImage varchar(50)
                );";
            $sql1 = "CREATE TABLE IF NOT EXISTS $table2 (
                ItemID int,
                Reviewer_name varchar(50),
                Review LONGTEXT,
                FOREIGN KEY (ItemID) REFERENCES $table(ItemID)
                );";
            $sql2 = "CREATE TABLE IF NOT EXISTS $table3 (
                CartID int NOT NULL PRIMARY KEY,
                ItemID int,
                BuyerUserID int,
                FOREIGN KEY (ItemID) REFERENCES $table(ItemID)
            );";
            if (mysqli_query($con, $sql)) {
                echo "Table $table created<br>";
                if (mysqli_query($con, $sql1)) {
                    echo "Table $table2 created<br>";
                    if (mysqli_query($con, $sql2)) {
                        echo "Table $table3 created<br>";
                        // $sql2 = "DROP TABLE $table3, $table2, $table;";
                        // if (mysqli_query($con, $sql2)) {
                        //     echo "$table, $table2 and $table3 dropped.<br>";
                        // } else {
                        //     echo "Error dropping tables.<br>";
                        // }
                    }
                } else {
                    echo "error in $table2<br>";
                }
            } else {
                echo "Error in creating table $table";
            }
        } else {
            echo "Error selecting the database.<br>";
        }
    } else {
        echo "Database created unsuccessfully.<br>";
    }
    $sql = "INSERT INTO $table VALUES 
        (1,2,\"Fundementals of Database Systems\",\"This is a used introductory based textbook for database courses. I have been using this book for long now, especially when I was taking database courses at the University of Calgary like CPSC 471 and 571.\",\"20.00\",1,\"Used items\",\"2.00\",\"January 14th\",\"DatabaseTextbook.jpg\"),
        (2,3,\"Operating Systems Concepts\",\"A used textbook for operating systems course.\",\"25.00\",1,\"Used items\",\"3.00\",NULL,\"opreatingSystemsBook.jpg\"),
        (3,1,\"Computer Networking: A Top-Down Approach (Seventh Edition)\",\"A new introductory textbook for computer networks course\",\"30.00\",1,\"New items\",\"4.00\",\"December 24th\",\"NetworkingTextbook.jpg\"),
        (4,5,\"Digital Design\",\"A new introductory based textbook for helping you understand how the digital design works\",\"30.00\",1,\"New items\",\"4.00\",\"February 4th\",\"DigitalDesignText.jpg\"),
        (5,2,\"Introduction to Python\",\"A used introductory undergraduate-level textbook for introducting you to Python\",\"15.00\",1,\"Used items\",\"1.00\",\"March 1th\",\"PythonTextbook.jpg\"),
        (6,2,\"Introduction to Java\",\"A new introductory undergraduate-level textbook for learning JAVA\",\"12.00\",1,\"New items\",\"1.00\",\"June 12th\",\"JavaTextbook.jpg\"),
        (7,6,\"Descrete Math\",\"A used introductory based textbook for junior level computer science oriented math courses\",\"25.00\",1,\"Used items\",\"2.00\",\"July 18th\",\"DiscreteMathTextbook.jpg\"),
        (8,9,\"Introductory Statistics\",\"A used introductory statistics textbook for helping you understand basic probability\",\"22.00\",1,\"Used items\",\"1.50\",\"February 21th\",\"StatisticsTextbook.jpg\"),
        (9,11,\"Vector Calculus\",\"A new introductory textbook for calculus courses.\",\"40.00\",1,\"New items\",\"4.00\",\"January 13th\",\"VectorCalculus.jpg\"),
        (10,22,\"Introduction to Differential equations\",\"A new textbook for basic coverage of differential equations\",\"26.00\",1,\"New items\",\"2.00\",\"May 30th\",\"DifferentialEquationsTextbook.jpg\")
    ;";

    $sql2 = "SELECT * FROM ITEM;";
    if ($result = mysqli_query($con, $sql2)) {
        
        // $result = mysqli_query($con, $sql2);

        print "<table border=1><tr><th>ItemID</th><th>SellerUserID</th><th>ItemName</th><th>ItemDescription</th><th>ItemPrice</th><th>NumberOfItems</th><th>CategoryID</th><th>ShipPrice</th><th>ArrivalDate</th><th>ItemImage</th></tr>";
        $output = array();
        $rowNumber = 0;
        while($row = mysqli_fetch_array($result)) {
            print "<tr><td>$row[ItemID]</td><td>$row[SellerUserID]</td><td>$row[ItemName]</td><td>$row[ItemDescription]</td><td>$row[ItemPrice]</td><td>$row[NumberOfItems]</td><td>$row[CategoryID]</td><td>$row[ShipPrice]</td><td>$row[ArrivalDate]</td><td>$row[ItemImage]</td></tr>";
        }
        print "</table>";
    } else {
        print "error<br>";
    }
    $sql = "INSERT INTO $table2 VALUES 
        (1, \"Anonymous User 1\",\"This book begins by explaining that while SQL is a little more complicated to learn than some other programming languages, once it is learned you can really do some neat stuff with it. The author explains that some of the more popular uses for SQL involve databases, and also that places like Facebook, Instagram and Pandora use SQL to manage user data. I thought it was a very nice touch, in addition to the sample walk through examples, there are several exercises and even a project to try out at the end of the book. This allows the reader to try their hand at working with SQL in real world circumstances. Overall, I look forward to continuing to work with SQL.\"),
        (1, \"Anonymous User 2\",\"This database language can be confusing, at least it is for me, but it's explained in simple terms in this book . This book covers the essentials and will teach you how to get started learning SQL. This book helped me learn the basics, of SQL and data science . I will be reading this book again, so I can fully comprehend it. But so worth the read .\"),
        (2, \"Anonymous User 1\",\"This is what computer-related books should be like. It is thorough, in depth, information packed, authoritative, and exhaustive. You cannot get this kind of excellent information from the Internet - or many other computer books these days.\"),
        (2, \"Anonymous User 2\",\"Great book, only the pages are uncolored, and some features are not in the book that are only available in e-text,e-book,ePUB or whatever it is called. You need to read both to get its full potential. Defeats a bit of my purpose to reduce eye strain.\"),
        (3, \"Anonymous User 1\",\"The book TITLE is a great concept. The author does a decent job of explaining things but does it in unnecessary length with craptastic diagrams. I've been studying this book in class for almost 3 months now and it was supposed to be a substitution for another book because it would save students money...I honestly would've dished out the extra cash for a more readable and cohesive textbook.\"),
        (3, \"Anonymous User 2\",\"I had to buy this book for class. The kindle version is way way overpriced. The content of the book is poorly written, dry, and poorly structured.Only buy this book if you have to.\"),
        (4, \"Anonymous User 1\",\"It reads like, while writing this, both writers were on different drugs and competing to see how long and drawn out they could make simple ideas. Most paragraphs in this book take up at least 1/3 the page. Each sentence is about 70% wasted filler. Why does this $200 abomination exist? Simple: the old version has a perfectly usable pdf and that doesn't help Pearson's profit margins.\"),
        (4, \"Anonymous User 2\",\"For at least 30 years Mano has been the go-to guy for digital design. I used his book in the 80s and now my son used it in 2017. He's still the king after all these years!\"),
        (5, \"Anonymous User 1\",\"Excellent content, and it is free. In my opinion, this book is written by an intelligent author that uses a direct and understandable language. The book really teaches Phyton and programming, and goes to the point. I had already paid for another Phyton book for beginners and it was terrible. Thank God I found this one after the other one.\"),
        (5, \"Anonymous User 2\",\"I wrote my first line of code, in ForTran77, in 1986. I've written a pretty good bit of code since then in a variety of languages. This is an excellent primer if you want to learn Python3 syntax. For those that have never written any code...this should still be pretty easy for you. The coding examples are straightforward.\"),
        (6, \"Anonymous User 1\",\"Over 1200 pages small print difficult to read fantastic content. I think he should’ve split the book in two parts because as it stands right now it’s very heavy has a lot of heft to it. Because it’s so heavy it’s actually difficult to get comfortable with to read it and learn. The content is fantastic and very easy to follow. I just wish did the format that it was presented in maybe in 3 books a third of the way it would be a lot easier.\"),
        (6, \"Anonymous User 2\",\"I have completed the first 10 chapters of the book. I have found the material to be laid out very logically and easy to follow. I look forward to completing the book and additional materials that are supplemental online.\"),
        (7, \"Anonymous User 1\",\"In my former career as a Research Physicist, I was very comfortable with continuous mathematics i.e. real numbers, calculus, PDE etc. In my current career as a software engineer / computer scientist I wanted a deeper appreciation for the algorithms, I was developing and reading about, a better feel for the mathematics underlying computer science. After surveying a number of texts - I was extremely fortunate to have found Gary Chartrand's Discrete Mathematics. Over the course of 4 months I consistently (~750 pomodoros) worked through this book, making notes, doing exercises and applying the insights into my own work.\"),
        (7, \"Anonymous User 2\",\"The book itself is fun to read, Chartrand, has done an excellent job, in explaining sometimes complex concepts and making them accessible to the reader. The book is extremely well written - I found myself saying wow! a few times whilst reading the book. Most importantly the book has given me such a solid foundation in my career as a software engineer, helped me breeze through various Coursera courses, and increased my appreciation for such a beautiful subject.\"),
        (8, \"Anonymous User 1\",\"Used this text for a Stat class. Book has many typos and made content in examples hard to interpret. Eventually had to look at an older edition to find the book had a typo. Found many additional typos in the book throughout chapters and words misplaced. You can tell editing of the book was not completed thoroughly or was extremely rushed. I can handle a typo here and there, but when the content starts becoming wrong in actual examples, that is where I draw the line.\"),
        (8, \"Anonymous User 2\",\"Just what I was expected, renting textbooks is the way to go.\"),
        (9, \"Anonymous User 1\",\"The conten is board and concise about vectors, derivatives and integrals. I like the functions of various variables, find domain and range for these functions and representacion in a tree diagram on page 82, figure 2.19.\"),
        (9, \"Anonymous User 2\",\"Too much color coding. This is why I got turned off with math since middle school. Also not enough interesting illustrations. The author needs to think about the connotations of the word illustrative.\"),
        (10, \"Anonymous User 1\",\"The writing style is excellent simple words, simple sentences. The margins are really wide and that's an awesomely helpful thing to have, with your pencil in hand though the examples are so detailed you might not need to add a lot. The examples even have little titles about what's going on great for reference, when combing back through the book after a while, which I do as a physics grad student.\"),
        (10, \"Anonymous User 2\",\"Libro prodotto in versione economica da Dover, la ristampa utilizzata è in binanco nero e non scala di griggio. Pertanto purtroppo in diverse parti come riquadri di testo ed immagini risulta poco leggibile e di bassa qualità.\")
    ;";
    
    $sql2 = "SELECT * FROM $table2;";
    if ($result = mysqli_query($con, $sql2)) {
        
        // $result = mysqli_query($con, $sql2);

        print "<table border=1><tr><th>ItemID</th><th>Reviewer_name</th><th>Review</th></tr>";
        $output = array();
        $rowNumber = 0;
        while($row = mysqli_fetch_array($result)) {
            print "<tr><td>$row[ItemID]</td><td>$row[Reviewer_name]</td><td>$row[Review]</td></tr>";
        }
        print "</table>";
    } else {
        print "error<br>";
    }
    $sql3 = "SELECT * FROM $table3;";
    if ($result = mysqli_query($con, $sql3)) {
        
        // $result = mysqli_query($con, $sql2);

        print "<table border=1><tr><th>CartID</th><th>ItemID</th><th>BuyerUserID</th></tr>";
        $output = array();
        $rowNumber = 0;
        while($row = mysqli_fetch_array($result)) {
            print "<tr><td>$row[CartID]</td><td>$row[ItemID]</td><td>$row[BuyerUserID]</td></tr>";
        }
        print "</table>";
    } else {
        print "error<br>";
    }
?>    
</body>
</html>
