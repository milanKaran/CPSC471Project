<?php
    function getItem($con, $itemID) {
        $query = "SELECT * FROM ITEM WHERE ItemID=$itemID;";
        return mysqli_query($con, $query);
    }
    function deleteItem($con, $itemID) {
        $query = "DELETE * FROM ITEM WHERE ItemID=$itemID;";
        return mysqli_query($con, $query);
    }
    function getReviews($con, $itemID) {
        $query = "SELECT Reviewer_name, Review FROM ITEM_REVIEWS WHERE ItemID=$itemID;";
        return mysqli_query($con, $query);
    }
?>




