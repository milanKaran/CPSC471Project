
<?php
    $connection = mysqli_connect("localhost", "root", "root", "BuyingAndSelling");
    if(isset($_POST["add_to_cart"])) {
        $hiddenId = $_POST['hiddenId'];
        echo $hiddenId;
        $query = "INSERT INTO CART VALUES
        (1, $hiddenId, 1)
        ;";
        if (mysqli_query($connection, $query)) {
            exit;
        }
        // if (isset($_SESSION["shopping_cart"])) {
        //     $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
        //     if (!in_array($_GET["ItemID"], $item_array_id)) {
        //         $count = count($_SESSION["shopping_cart"]);
        //         $item_array = array(
        //             'item_id' => $_GET["ItemID"],
        //             'item_category' => $_POST["hidden_category"],
        //             'item_quantity' => $_POST["hidden_quantity"],
        //             'item_name' => $_POST["hidden_name"],
        //             'item_price' => $_POST["hidden_price"],
        //             'item_shipping_price' => $_POST["hidden-shipping-price"]
        //         );
        //         $_SESSION["shopping_cart"][$count] = $item_array;
        //     } else {
        //         echo '<script>Item already added.</script>';
        //         echo '<script>window.location="itemDisplay.php"</script>';
        //     }
        // } else {
        //     $item_array = array(
        //         'item_id' => $_GET["ItemID"],
        //         'item_category' => $_POST["hidden_category"],
        //         'item_quantity' => $_POST["hidden_quantity"],
        //         'item_name' => $_POST["hidden_name"],
        //         'item_price' => $_POST["hidden_price"],
        //         'item_shipping_price' => $_POST["hidden-shipping-price"]
        //     );
        //     $_SESSION["shopping_cart"][0] = $item_array;
        // }
    }
    if (isset($_GET["action"])) {
        if ($_GET["action"] == "delete") {
            foreach($_SESSION["shopping_cart"] as $keys => $values) {
                if ($values["item_id"] == $_GET["id"]) {
                    unset($_SESSION["shopping_cart"][$keys]);
                    echo '<script>Item removed.</script>';
                    echo '<script>window.location="cartDisplay.php"</script>';
                }
            }
        }
    }

    function getCartItems($connection, $CartID) {
        $query = "SELECT ItemName, ItemPrice, CategoryID, ShipPrice, NumberOfItems FROM ITEM, CART WHERE ITEM.ItemID = CART.ItemID AND CART.CartID = $CartID;";
        return mysqli_query($connection, $query);
    }

?>